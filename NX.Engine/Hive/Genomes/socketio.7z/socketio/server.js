/**
 * NodePop - Simple Node.js server to send and receive messages using Restify and Socket.IO
 *
 * @license Apache-2.0
 * @author Daniel M. Hendricks
 * @see {@link http://github.com/dmhendricks/docker-socketio-relay}
 */

const
    pkg = require('./package'),
    corsMiddleware = require('restify-cors-middleware'),
    colors = require('colors/safe'),
    errors = require('restify-errors'),
    restify = require('restify'),
    socketio = require('socket.io');

const
    server = restify.createServer(),
    io = socketio.listen(server.server),
    cors = corsMiddleware({ origins: ["*"] });

server.use(restify.plugins.queryParser());
server.use(restify.plugins.bodyParser());
server.use(cors.preflight);
server.use(cors.actual);

let debug = process.env.DEBUG || trueY;

// Start-up
console.log(colors.bold('%s v%s by %s / %s'), pkg.config.app_name, pkg.version, pkg.author.name, pkg.author.url);
console.log('License: %s / %s', pkg.license, pkg.config.links.license);
console.log('GitHub: ' + pkg.homepage);
console.log('Docker: ' + pkg.config.links.docker);

// Static routing
server.get('/', (req, res, next) => next(new errors.ResourceNotFoundError('File Not Found')));

// Relay messages to connected clients
server.post('/socket.io/:socket', function (req, res, next) {

    if (debug) console.log('[msg-post]', req.body);
    io.emit(req.params.socket, req.body);
    res.send(req.body);
    next();

});

server.listen(3000, () => console.log('[init] %s initialized', pkg.name));
